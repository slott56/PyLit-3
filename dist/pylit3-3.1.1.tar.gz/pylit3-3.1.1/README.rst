############
PyLit 3.1
############


See http://slott56.github.io/PyLit-3/index.html for the complete documentation.

The ``Makefile`` is used via ``make html`` to rebuild the code and documentation.

The ``docs`` directory contains the documentation, plus many examples.

The ``pylit.py`` is the module.  Once you've installed it, use ``python -m pylit`` to run it.

The ``test`` directory contains the unit test suite.

The ``contribs`` directory are old contributed modules which have not yet been
converted to Python3.

The code repository is: https://github.com/slott56/PyLit-3
